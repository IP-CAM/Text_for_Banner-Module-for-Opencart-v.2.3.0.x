<?php
class ModelExtensionTextForBanner extends Model {

	public function create_field(){

		$this->db->query("ALTER TABLE " . DB_PREFIX . "banner_image ADD text_for_banner VARCHAR(50)");
		$this->db->query("ALTER TABLE " . DB_PREFIX . "banner_image ADD style_for_banner TEXT");

	}

	public function delete_field(){
		$this->db->query("ALTER TABLE " . DB_PREFIX . "banner_image DROP COLUMN text_for_banner");
		$this->db->query("ALTER TABLE " . DB_PREFIX . "banner_image DROP COLUMN style_for_banner");

	}

	public function modificator_on(){		
		$this->db->query("UPDATE " . DB_PREFIX . "modification SET status = 1 WHERE code = 'text_for_banner'");
	}

	public function modificator_of(){
		$this->db->query("UPDATE " . DB_PREFIX . "modification SET status = 0 WHERE code = 'text_for_banner'");
	}

	public function modificator_check() {
		$this->load->model('setting/setting');
		return $this->model_setting_setting->getSettingValue('textForBanner_status');
	}
}

